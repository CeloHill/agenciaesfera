import{p as o,M as e}from"#entry";const t=o("/videos/video-intro-esfera.mp4"),a=()=>{const{$gsap:s,$ScrollTrigger:r}=e();return{gsap:s,ScrollTrigger:r}};export{t as _,a as u};
